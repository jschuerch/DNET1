﻿namespace P09_ADO.NET_form {
    internal class DateTimeToString {
        private string v;

        public DateTimeToString(string v) {
            this.v = v;
        }
    }
}
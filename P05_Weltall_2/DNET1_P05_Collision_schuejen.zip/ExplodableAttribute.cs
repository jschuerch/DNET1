﻿using System;

namespace P05_Weltall_2
{
    internal class ExplodableAttribute : Attribute
    {
    }
}